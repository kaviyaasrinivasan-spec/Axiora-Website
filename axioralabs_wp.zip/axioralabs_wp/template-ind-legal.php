<?php /* Template Name: Axiora — Legal Services */ get_header(); ?>
<main id="top">
  <!-- HERO -->
  <section class="page-hero">
    <div class="wrap ind-hero">
      <div class="copy reveal">
        <span class="eyebrow">Industries · Legal Services</span>
        <h1>AI Automation for <span class="grad">Legal Services</span></h1>
        <p class="sub">Review contracts in minutes, never miss a risky clause, and automate the document-heavy grind — so your team spends time on advice, not admin.</p>
        <div class="hcta">
          <a class="btn btn-primary" href="/contact/">Book an Automation Assessment <svg class="icon"><use href="#i-arrow"/></svg></a>
          <a class="btn btn-ghost" href="/cargora/">See Our Platforms</a>
        </div>
      </div>
      <div class="viswrap reveal">
        <div class="float-chip one"><span class="fc-ic" style="background:linear-gradient(135deg,#10b981,#34d399)"><svg class="icon"><use href="#i-check"/></svg></span><span><b>80%</b><span>Faster review</span></span></div>
        <div class="float-chip two"><span class="fc-ic" style="background:linear-gradient(135deg,#3c59e7,#6b7cef)"><svg class="icon"><use href="#i-shield"/></svg></span><span><b>Zero</b><span>Missed clauses</span></span></div>
        <div class="ops-panel">
          <div class="ops-top"><span class="dots"><i style="background:#ff5f57"></i><i style="background:#febc2e"></i><i style="background:#28c840"></i></span><span class="vt"><svg class="icon"><use href="#i-scale"/></svg> Axiora Labs Copilot · Legal Operations</span></div>
          <div class="ops-body">
            <div class="ship-row"><span class="ship-ico"><svg class="icon"><use href="#i-file"/></svg></span><span class="ship-txt"><b>CTR-3312 · Vendor contract</b><span>Clauses extracted</span></span><span class="pill auto">Extracted</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#f97316,#ea580c)"><svg class="icon"><use href="#i-search"/></svg></span><span class="ship-txt"><b>REV-2201 · Clause variance</b><span>3 risks flagged</span></span><span class="pill transit">Reviewing</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#a855f7,#7c3aed)"><svg class="icon"><use href="#i-layers"/></svg></span><span class="ship-txt"><b>DOC-778 · Discovery batch</b><span>Reviewed &amp; tagged</span></span><span class="pill cleared">Tagged</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#0ea5e9,#3c59e7)"><svg class="icon"><use href="#i-bulb"/></svg></span><span class="ship-txt"><b>DRF-119 · NDA draft</b><span>Generated from template</span></span><span class="pill delivered">Drafted</span></div>
            <div class="ops-bar"><span></span></div>
            <div class="ops-cap">80% of routine contract review handled automatically</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- UNDERSTANDING -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The industry</span><h2>What Legal Teams Run On</h2><p>A profession built on documents — contracts, briefs, filings and research.</p></div>
      <div class="seg-grid">
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-scale"/></svg></span><b>Law Firms</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-building"/></svg></span><b>Corporate &amp; In-house Legal</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-users"/></svg></span><b>Legal Process Outsourcing</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-shield"/></svg></span><b>Compliance &amp; Regulatory</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-file"/></svg></span><b>Contract Management</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-search"/></svg></span><b>Litigation Support</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-award"/></svg></span><b>IP &amp; Patents</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-layers"/></svg></span><b>Records &amp; Filing</b></div>
      </div>
    </div>
  </section>

  <!-- BOTTLENECKS -->
  <section class="section bg-soft">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The problem</span><h2>Where Legal Teams Lose Billable Hours</h2><p>The repetitive document work that buries lawyers and paralegals.</p></div>
      <div class="pain-grid">
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-file"/></svg></span><p>Line-by-line <b>contract review</b> &amp; clause analysis.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-search"/></svg></span><p>Spotting <b>clause variances &amp; risks</b> across versions.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-bulb"/></svg></span><p>Drafting <b>boilerplate contracts</b> &amp; standard docs.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-layers"/></svg></span><p><b>Document review &amp; e-discovery</b> at scale.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-users"/></svg></span><p>Manual <b>client intake &amp; matter setup</b>.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-globe"/></svg></span><p>Time-consuming <b>legal research</b> &amp; summarization.</p></div>
      </div>
    </div>
  </section>

  <!-- HOW WE AUTOMATE -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">How it works</span><h2>How Axiora Labs Automates It</h2><p>AI does the first pass — your lawyers review, refine and approve.</p></div>
      <div class="flow reveal">
        <div class="flow-step" style="--c1:#3c59e7;--c2:#22d3ee"><span class="flow-ico"><svg class="icon"><use href="#i-file"/></svg></span><b>Legal Docs</b><span>Contracts · briefs · filings</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#a855f7;--c2:#ec4899"><span class="flow-ico"><svg class="icon"><use href="#i-bot"/></svg></span><b>AI Analyze</b><span>Reads &amp; understands</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#f97316;--c2:#ef4444"><span class="flow-ico"><svg class="icon"><use href="#i-search"/></svg></span><b>Extract &amp; Flag</b><span>Clauses &amp; risks</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#10b981;--c2:#34d399"><span class="flow-ico"><svg class="icon"><use href="#i-check"/></svg></span><b>Draft &amp; Compare</b><span>Against your standards</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#6366f1;--c2:#8b5cf6"><span class="flow-ico"><svg class="icon"><use href="#i-database"/></svg></span><b>Filed &amp; Tracked</b><span>Matter &amp; records systems</span></div>
      </div>
    </div>
  </section>

  <!-- HOW WE HELP -->
  <section class="section bg-soft">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">Our edge</span><h2>How We Help Legal Teams</h2><p>AI copilots &amp; document intelligence tuned to legal work.</p></div>
      <div class="prod-grid">
        <div class="prod-card reveal" style="--c1:#3c59e7;--c2:#22d3ee"><span class="prod-ico"><svg class="icon"><use href="#i-bot"/></svg></span><h3>Legal Document Copilot</h3><p>Summarizes contracts &amp; briefs, answers questions, and drafts standard documents from your templates.</p></div>
        <div class="prod-card reveal" style="--c1:#f97316;--c2:#ea580c"><span class="prod-ico"><svg class="icon"><use href="#i-search"/></svg></span><h3>Contract &amp; Clause AI</h3><p>Extracts clauses, flags variances &amp; risks, and compares against your playbook.</p></div>
        <div class="prod-card reveal" style="--c1:#10b981;--c2:#34d399"><span class="prod-ico"><svg class="icon"><use href="#i-zap"/></svg></span><h3>Workflow Automation</h3><p>Automate intake, matter setup, filing &amp; reminders across your tools.</p></div>
        <div class="prod-card reveal" style="--c1:#a855f7;--c2:#7c3aed"><span class="prod-ico"><svg class="icon"><use href="#i-rocket"/></svg></span><h3>Custom AI Products</h3><p>We build production-ready AI platforms end-to-end — proven with Cargora &amp; iClinicalAI.</p></div>
      </div>
    </div>
  </section>

  <!-- IMPACT -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The impact</span><h2>What Changes for Your Practice</h2><p>Faster turnaround, lower risk, and more time for high-value work.</p></div>
      <div class="ben-grid">
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-clock"/></svg></div><b>Faster Contract Turnaround</b><span>Review in minutes, not hours.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-shield"/></svg></div><b>Fewer Missed Risks</b><span>Consistent clause &amp; risk detection.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-trend"/></svg></div><b>More Billable Time</b><span>Less grunt work, more advisory.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-dollar"/></svg></div><b>Lower Cost per Matter</b><span>Do more with the same team.</span></div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="cta">
    <div class="wrap cta-inner reveal">
      <h2>Turn Documents into Advantage</h2>
      <p>Book a free automation assessment and we'll map where AI can speed up contract review, drafting and research for your team.</p>
      <div class="cta-btns"><a class="btn btn-white" href="/contact/">Book an Assessment <svg class="icon"><use href="#i-arrow"/></svg></a><a class="btn btn-white-ghost" href="/cargora/">See Our Platforms</a></div>
    </div>
  </section>
</main>

<?php get_footer(); ?>
