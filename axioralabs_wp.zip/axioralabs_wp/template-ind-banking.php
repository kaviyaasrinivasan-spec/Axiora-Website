<?php /* Template Name: Axiora — Banking & Financial Services */ get_header(); ?>
<main id="top">
  <!-- HERO -->
  <section class="page-hero">
    <div class="wrap ind-hero">
      <div class="copy reveal">
        <span class="eyebrow">Industries · Banking &amp; Financial Services</span>
        <h1>AI Automation for <span class="grad">Banking &amp; Finance</span></h1>
        <p class="sub">Onboard customers faster, process documents instantly, and stay compliant — with secure AI automation that works alongside your core banking, lending and CRM systems.</p>
        <div class="hcta">
          <a class="btn btn-primary" href="/contact/">Book an Automation Assessment <svg class="icon"><use href="#i-arrow"/></svg></a>
          <a class="btn btn-ghost" href="/cargora/">See Our Platforms</a>
        </div>
      </div>
      <div class="viswrap reveal">
        <div class="float-chip one"><span class="fc-ic" style="background:linear-gradient(135deg,#10b981,#34d399)"><svg class="icon"><use href="#i-check"/></svg></span><span><b>88%</b><span>Auto-verified</span></span></div>
        <div class="float-chip two"><span class="fc-ic" style="background:linear-gradient(135deg,#3c59e7,#6b7cef)"><svg class="icon"><use href="#i-shield"/></svg></span><span><b>Secure</b><span>&amp; compliant</span></span></div>
        <div class="ops-panel">
          <div class="ops-top"><span class="dots"><i style="background:#ff5f57"></i><i style="background:#febc2e"></i><i style="background:#28c840"></i></span><span class="vt"><svg class="icon"><use href="#i-bank"/></svg> Axiora Labs Copilot · Banking Operations</span></div>
          <div class="ops-body">
            <div class="ship-row"><span class="ship-ico"><svg class="icon"><use href="#i-shield"/></svg></span><span class="ship-txt"><b>KYC-8821 · New account</b><span>Documents verified</span></span><span class="pill cleared">Verified</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#a855f7,#7c3aed)"><svg class="icon"><use href="#i-file"/></svg></span><span class="ship-txt"><b>STMT-4410 · Bank statement</b><span>Data auto-extracted</span></span><span class="pill auto">Extracted</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#f97316,#ea580c)"><svg class="icon"><use href="#i-dollar"/></svg></span><span class="ship-txt"><b>LOAN-2207 · Credit docs</b><span>Processed &amp; scored</span></span><span class="pill transit">Processing</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#0ea5e9,#3c59e7)"><svg class="icon"><use href="#i-scale"/></svg></span><span class="ship-txt"><b>AML-119 · Compliance report</b><span>Auto-generated</span></span><span class="pill delivered">Filed</span></div>
            <div class="ops-bar"><span></span></div>
            <div class="ops-cap">88% of KYC &amp; documents processed automatically</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- UNDERSTANDING -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The industry</span><h2>What Banking &amp; Finance Runs On</h2><p>Document-heavy, compliance-critical operations across every financial vertical.</p></div>
      <div class="seg-grid">
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-bank"/></svg></span><b>Retail Banking</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-building"/></svg></span><b>Corporate Banking</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-dollar"/></svg></span><b>Lending &amp; Loans</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-trend"/></svg></span><b>Wealth &amp; Asset Management</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-layers"/></svg></span><b>Payments</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-cpu"/></svg></span><b>NBFCs &amp; Fintech</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-shield"/></svg></span><b>Risk &amp; Compliance</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-phone"/></svg></span><b>Customer Support</b></div>
      </div>
    </div>
  </section>

  <!-- BOTTLENECKS -->
  <section class="section bg-soft">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The problem</span><h2>Where Financial Teams Lose Time</h2><p>The manual, document-heavy work that slows onboarding and creates compliance risk.</p></div>
      <div class="pain-grid">
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-shield"/></svg></span><p>Manual <b>KYC document intake</b> &amp; verification.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-file"/></svg></span><p>Reading <b>bank statements, cheques &amp; forms</b> by hand.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-database"/></svg></span><p><b>Ledger matching &amp; reconciliation</b> across systems.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-dollar"/></svg></span><p>Slow <b>loan &amp; credit document processing</b>.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-phone"/></svg></span><p>High volume of repetitive <b>customer queries</b>.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-scale"/></svg></span><p>Manual <b>AML &amp; compliance reporting</b>.</p></div>
      </div>
    </div>
  </section>

  <!-- HOW WE AUTOMATE -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">How it works</span><h2>How Axiora Labs Automates It</h2><p>Secure, auditable automation from document intake to compliance.</p></div>
      <div class="flow reveal">
        <div class="flow-step" style="--c1:#3c59e7;--c2:#22d3ee"><span class="flow-ico"><svg class="icon"><use href="#i-file"/></svg></span><b>Documents In</b><span>KYC · statements · loans</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#a855f7;--c2:#ec4899"><span class="flow-ico"><svg class="icon"><use href="#i-bot"/></svg></span><b>AI Extract</b><span>Reads &amp; captures data</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#f97316;--c2:#ef4444"><span class="flow-ico"><svg class="icon"><use href="#i-check"/></svg></span><b>Verify &amp; Reconcile</b><span>Checks &amp; flags risk</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#10b981;--c2:#34d399"><span class="flow-ico"><svg class="icon"><use href="#i-database"/></svg></span><b>Core Banking / CRM</b><span>Updated automatically</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#6366f1;--c2:#8b5cf6"><span class="flow-ico"><svg class="icon"><use href="#i-shield"/></svg></span><b>Compliance &amp; Alerts</b><span>Audit-ready reports</span></div>
      </div>
    </div>
  </section>

  <!-- HOW WE HELP -->
  <section class="section bg-soft">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">Our edge</span><h2>How We Help Financial Teams</h2><p>Secure document AI &amp; automation, integrated with your core systems.</p></div>
      <div class="prod-grid">
        <div class="prod-card reveal" style="--c1:#f97316;--c2:#ea580c"><span class="prod-ico"><svg class="icon"><use href="#i-flow"/></svg></span><h3>BoostEntry AI</h3><p>Extracts data from KYC docs, bank statements, cheques &amp; loan forms — validated and pushed into your systems.</p><a class="prod-link" href="https://boostentryai.com/" target="_blank" rel="noopener">Visit BoostEntry AI <svg class="icon"><use href="#i-arrow"/></svg></a></div>
        <div class="prod-card reveal" style="--c1:#3c59e7;--c2:#22d3ee"><span class="prod-ico"><svg class="icon"><use href="#i-bot"/></svg></span><h3>AI Support Copilots</h3><p>Deflect &amp; resolve routine customer and back-office queries with secure AI assistants.</p></div>
        <div class="prod-card reveal" style="--c1:#10b981;--c2:#34d399"><span class="prod-ico"><svg class="icon"><use href="#i-lock"/></svg></span><h3>Secure Integrations</h3><p>Connect core banking, CRM &amp; accounting on secure cloud architecture — compliance-first.</p></div>
        <div class="prod-card reveal" style="--c1:#a855f7;--c2:#7c3aed"><span class="prod-ico"><svg class="icon"><use href="#i-rocket"/></svg></span><h3>Custom AI Products</h3><p>We build production-ready AI platforms end-to-end — proven with Cargora &amp; iClinicalAI.</p></div>
      </div>
    </div>
  </section>

  <!-- IMPACT -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The impact</span><h2>What Changes for Your Institution</h2><p>Faster service, cleaner data, and stronger compliance.</p></div>
      <div class="ben-grid">
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-clock"/></svg></div><b>Faster Onboarding &amp; Loans</b><span>KYC &amp; credit docs processed in minutes.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-check"/></svg></div><b>Fewer Errors</b><span>Automated extraction &amp; reconciliation.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-shield"/></svg></div><b>Stronger Compliance</b><span>Audit-ready, consistent reporting.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-dollar"/></svg></div><b>Lower Operating Cost</b><span>Less manual processing, faster throughput.</span></div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="cta">
    <div class="wrap cta-inner reveal">
      <h2>Automate Your Financial Operations — Securely</h2>
      <p>Book a free automation assessment and we'll map where AI can speed up onboarding, cut document processing, and strengthen compliance.</p>
      <div class="cta-btns"><a class="btn btn-white" href="/contact/">Book an Assessment <svg class="icon"><use href="#i-arrow"/></svg></a><a class="btn btn-white-ghost" href="/cargora/">See Our Platforms</a></div>
    </div>
  </section>
</main>

<?php get_footer(); ?>
