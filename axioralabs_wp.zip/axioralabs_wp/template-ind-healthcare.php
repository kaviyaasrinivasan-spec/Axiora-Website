<?php /* Template Name: Axiora — Healthcare */ get_header(); ?>
<main id="top">
  <!-- HERO -->
  <section class="page-hero">
    <div class="wrap ind-hero">
      <div class="copy reveal">
        <span class="eyebrow">Industries · Healthcare</span>
        <h1>AI Automation for <span class="grad">Healthcare</span></h1>
        <p class="sub">Free your clinical and admin teams from paperwork — automate patient operations, insurance &amp; records, and accelerate research with our clinical AI platform, iClinicalAI.</p>
        <div class="hcta">
          <a class="btn btn-primary" href="/contact/">Book an Automation Assessment <svg class="icon"><use href="#i-arrow"/></svg></a>
          <a class="btn btn-ghost" href="https://iclinical.ai/" target="_blank" rel="noopener">Explore iClinicalAI</a>
        </div>
      </div>
      <div class="viswrap reveal">
        <div class="float-chip one"><span class="fc-ic" style="background:linear-gradient(135deg,#10b981,#34d399)"><svg class="icon"><use href="#i-check"/></svg></span><span><b>80%</b><span>Admin automated</span></span></div>
        <div class="float-chip two"><span class="fc-ic" style="background:linear-gradient(135deg,#a855f7,#7c3aed)"><svg class="icon"><use href="#i-heart"/></svg></span><span><b>Better</b><span>Patient care</span></span></div>
        <div class="ops-panel">
          <div class="ops-top"><span class="dots"><i style="background:#ff5f57"></i><i style="background:#febc2e"></i><i style="background:#28c840"></i></span><span class="vt"><svg class="icon"><use href="#i-heart"/></svg> Axiora Labs Copilot · Healthcare Operations</span></div>
          <div class="ops-body">
            <div class="ship-row"><span class="ship-ico"><svg class="icon"><use href="#i-clock"/></svg></span><span class="ship-txt"><b>APT-2201 · Appointment</b><span>Reminder sent to patient</span></span><span class="pill delivered">Reminded</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#a855f7,#7c3aed)"><svg class="icon"><use href="#i-shield"/></svg></span><span class="ship-txt"><b>INS-4410 · Eligibility</b><span>Insurance verified</span></span><span class="pill cleared">Verified</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#f97316,#ea580c)"><svg class="icon"><use href="#i-file"/></svg></span><span class="ship-txt"><b>REC-778 · Records intake</b><span>Data extracted → EHR</span></span><span class="pill auto">Extracted</span></div>
            <div class="ship-row"><span class="ship-ico" style="background:linear-gradient(135deg,#0ea5e9,#3c59e7)"><svg class="icon"><use href="#i-search"/></svg></span><span class="ship-txt"><b>RES-119 · Study data</b><span>Captured via iClinicalAI</span></span><span class="pill transit">Research</span></div>
            <div class="ops-bar"><span></span></div>
            <div class="ops-cap">80% of routine admin tasks handled automatically</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- UNDERSTANDING -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The industry</span><h2>What Healthcare Runs On</h2><p>From hospitals to research networks — operations weighed down by admin and paperwork.</p></div>
      <div class="seg-grid">
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-heart"/></svg></span><b>Hospitals</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-activity"/></svg></span><b>Clinics &amp; Diagnostics</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-search"/></svg></span><b>Research Networks</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-globe"/></svg></span><b>Public Health Programs</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-users"/></svg></span><b>Medical Colleges</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-cpu"/></svg></span><b>Healthtech</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-phone"/></svg></span><b>Patient Support</b></div>
        <div class="seg-card reveal"><span class="seg-ico"><svg class="icon"><use href="#i-file"/></svg></span><b>Records &amp; Billing</b></div>
      </div>
    </div>
  </section>

  <!-- BOTTLENECKS -->
  <section class="section bg-soft">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The problem</span><h2>Where Healthcare Teams Lose Time</h2><p>The admin burden that pulls staff away from patients and research.</p></div>
      <div class="pain-grid">
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-users"/></svg></span><p>Manual <b>patient admin workflows</b> &amp; scheduling.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-shield"/></svg></span><p>Reading <b>insurance eligibility &amp; claim</b> documents by hand.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-database"/></svg></span><p><b>Medical records &amp; EHR data entry</b> from paper/PDFs.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-dollar"/></svg></span><p><b>Vendor invoice &amp; billing</b> processing.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-phone"/></svg></span><p>High volume of <b>patient calls &amp; queries</b>.</p></div>
        <div class="pain-card reveal"><span class="px"><svg class="icon"><use href="#i-search"/></svg></span><p>Slow, manual <b>clinical research &amp; registry</b> work.</p></div>
      </div>
    </div>
  </section>

  <!-- HOW WE AUTOMATE -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">How it works</span><h2>How Axiora Labs Automates It</h2><p>AI handles the paperwork and coordination — your team focuses on care.</p></div>
      <div class="flow reveal">
        <div class="flow-step" style="--c1:#3c59e7;--c2:#22d3ee"><span class="flow-ico"><svg class="icon"><use href="#i-file"/></svg></span><b>Documents In</b><span>Records · claims · forms</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#a855f7;--c2:#ec4899"><span class="flow-ico"><svg class="icon"><use href="#i-bot"/></svg></span><b>AI Read</b><span>Extract &amp; understand</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#f97316;--c2:#ef4444"><span class="flow-ico"><svg class="icon"><use href="#i-check"/></svg></span><b>Verify &amp; Route</b><span>Eligibility &amp; approvals</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#10b981;--c2:#34d399"><span class="flow-ico"><svg class="icon"><use href="#i-database"/></svg></span><b>EHR / HIS</b><span>Updated automatically</span></div>
        <div class="flow-arrow"><svg class="icon"><use href="#i-right"/></svg></div>
        <div class="flow-step" style="--c1:#6366f1;--c2:#8b5cf6"><span class="flow-ico"><svg class="icon"><use href="#i-zap"/></svg></span><b>Alerts &amp; Support</b><span>Reminders &amp; patient care</span></div>
      </div>
    </div>
  </section>

  <!-- HOW WE HELP -->
  <section class="section bg-soft">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">Our edge</span><h2>How We Help Healthcare &amp; Research</h2><p>From patient operations to clinical research — powered by our platforms.</p></div>
      <div class="prod-grid">
        <div class="prod-card reveal" style="--c1:#3c59e7;--c2:#22d3ee"><span class="prod-ico"><svg class="icon"><use href="#i-spark"/></svg></span><h3>iClinicalAI</h3><p>Our production clinical-research platform — trial design, data management, safety, recruitment &amp; more. Ideal for research networks &amp; hospitals running studies.</p><a class="prod-link" href="https://iclinical.ai/" target="_blank" rel="noopener">Explore iClinicalAI <svg class="icon"><use href="#i-arrow"/></svg></a></div>
        <div class="prod-card reveal" style="--c1:#a855f7;--c2:#7c3aed"><span class="prod-ico"><svg class="icon"><use href="#i-bot"/></svg></span><h3>AI Patient-Support Copilot</h3><p>Handles appointment queries, reminders &amp; routine questions 24/7 to lighten front-desk load.</p></div>
        <div class="prod-card reveal" style="--c1:#f97316;--c2:#ea580c"><span class="prod-ico"><svg class="icon"><use href="#i-flow"/></svg></span><h3>Document AI</h3><p>Reads records, insurance &amp; billing documents and updates your EHR/HIS — no manual entry.</p><a class="prod-link" href="https://boostentryai.com/" target="_blank" rel="noopener">Visit BoostEntry AI <svg class="icon"><use href="#i-arrow"/></svg></a></div>
        <div class="prod-card reveal" style="--c1:#10b981;--c2:#059669"><span class="prod-ico"><svg class="icon"><use href="#i-rocket"/></svg></span><h3>Custom AI &amp; Integrations</h3><p>We build production-ready AI platforms end-to-end and integrate with your existing systems.</p></div>
      </div>
    </div>
  </section>

  <!-- IMPACT -->
  <section class="section">
    <div class="wrap">
      <div class="section-head reveal"><span class="eyebrow">The impact</span><h2>What Changes for Your Organization</h2><p>Less admin, faster billing, better patient experience — and accelerated research.</p></div>
      <div class="ben-grid">
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-clock"/></svg></div><b>Less Admin Burden</b><span>Staff freed for patient care.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-dollar"/></svg></div><b>Faster Billing &amp; Claims</b><span>Quicker eligibility &amp; reimbursement.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-heart"/></svg></div><b>Better Patient Experience</b><span>Faster responses &amp; reminders.</span></div>
        <div class="ben-card reveal"><div class="ben-ico"><svg class="icon"><use href="#i-trend"/></svg></div><b>Accelerated Research</b><span>Studies run faster with iClinicalAI.</span></div>
      </div>
    </div>
  </section>

  <!-- CTA -->
  <section class="cta">
    <div class="wrap cta-inner reveal">
      <h2>Bring AI to Your Healthcare Operations</h2>
      <p>Book a free automation assessment, or explore iClinicalAI for your research programs.</p>
      <div class="cta-btns"><a class="btn btn-white" href="/contact/">Book an Assessment <svg class="icon"><use href="#i-arrow"/></svg></a><a class="btn btn-white-ghost" href="https://iclinical.ai/" target="_blank" rel="noopener">Explore iClinicalAI</a></div>
    </div>
  </section>
</main>

<?php get_footer(); ?>
