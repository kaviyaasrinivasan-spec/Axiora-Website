<?php /* Template Name: WB — Contact */ get_header(); ?>
<main id="top">
  <section class="page-hero">
    <div class="wrap inner">
      <span class="eyebrow reveal">Get in touch</span>
      <h1 class="reveal">Get in Touch</h1>
      <p class="reveal">Our team responds within 24 business hours.</p>
    </div>
  </section>

  <section class="section" style="padding-top:20px">
    <div class="wrap">
      <div class="contact-grid">
        <!-- FORM -->
        <div class="form-card reveal">
          <div class="form-head">
            <h2>Book Your Free AI Automation Audit</h2>
            <p>Automate repetitive tasks, reduce manual work, and save hours every week.</p>
          </div>
          <form class="form-grid" onsubmit="return false">
            <div class="field">
              <label>Full Name <span class="req">*</span></label>
              <input type="text" name="fullName" placeholder="e.g. Rahul Sharma" required>
            </div>
            <div class="field">
              <label>Company Name <span class="req">*</span></label>
              <input type="text" name="companyName" placeholder="e.g. Acme Tech Solutions" required>
            </div>
            <div class="field">
              <label>Mobile Number <span class="req">*</span></label>
              <div class="phone-wrap"><span class="pfx">+91</span><input type="tel" name="mobileNumber" placeholder="9876543210" maxlength="10"></div>
            </div>
            <div class="field-row">
              <div class="field">
                <label>Number of Employees <span class="req">*</span></label>
                <select name="employeeCount"><option value="" disabled selected>Select range</option><option>1–10</option><option>11–25</option><option>26–50</option><option>51–100</option><option>100+</option></select>
              </div>
              <div class="field">
                <label>Implementation Timeline <span class="req">*</span></label>
                <select name="timeline"><option value="" disabled selected>Select option</option><option>Immediately</option><option>Within 1 Month</option><option>Within 3 Months</option><option>Just Exploring</option></select>
              </div>
            </div>
            <div class="field">
              <label>Biggest Repetitive Process <span class="req">*</span></label>
              <select name="repetitiveProcess"><option value="" disabled selected>Select process</option><option>Data Entry</option><option>Customer Follow-ups</option><option>Service Verification</option><option>Invoice Processing</option><option>Report Generation</option><option>Approval Workflow</option><option>Document Verification</option><option>Other</option></select>
            </div>
            <div class="field">
              <label>Tell us about your automation needs (Optional)</label>
              <textarea name="processDescription" placeholder="Tell us about the repetitive tasks or bottlenecks you want to solve…"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Book A Call <svg class="icon"><use href="#i-arrow"/></svg></button>
            <div class="form-note"><svg class="icon"><use href="#i-check"/></svg> We reply within 24 business hours. No spam, ever.</div>
          </form>
        </div>

        <!-- CONTACT SIDE -->
        <div class="contact-side">
          <div class="reveal">
            <h2 class="lead-h">Let's Talk Automation</h2>
            <p class="lead-p">Whether you have a specific project in mind or just want to explore how automation can help your business, we're here to help.</p>
          </div>
          <div class="cm-list">
            <a class="cm-card reveal" href="mailto:sales@axioralabs.ai"><span class="cm-ico" style="--c1:#3c59e7;--c2:#22d3ee"><svg class="icon"><use href="#i-mail"/></svg></span><span class="cm-txt"><b>Email</b><span>sales@axioralabs.ai</span></span></a>
            <a class="cm-card reveal" href="tel:+918122784236"><span class="cm-ico" style="--c1:#a855f7;--c2:#ec4899"><svg class="icon"><use href="#i-phone"/></svg></span><span class="cm-txt"><b>Phone</b><span>+91 8122784236</span></span></a>
            <a class="cm-card reveal" href="https://www.google.com/maps/search/?api=1&query=Nungambakkam+Chennai+600034" target="_blank" rel="noopener"><span class="cm-ico" style="--c1:#f97316;--c2:#ef4444"><svg class="icon"><use href="#i-pin"/></svg></span><span class="cm-txt"><b>Location</b><span>Chennai, India</span></span></a>
          </div>
          <div class="resp-card reveal">
            <div class="rc-ico"><svg class="icon"><use href="#i-clock"/></svg></div>
            <div class="rc-label">Average Response Time</div>
            <div class="rc-big">&lt; 24 hours</div>
            <div class="rc-sub">We typically respond to all inquiries within one business day.</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="cta">
    <div class="wrap cta-inner reveal">
      <h2>Let's Automate Your Business Today</h2>
      <p>Explore how AI automation can save your team hours every week and help you scale smarter.</p>
      <div class="cta-btns"><a class="btn btn-white" href="/cargora/">Explore Our Platforms <svg class="icon"><use href="#i-arrow"/></svg></a></div>
    </div>
  </section>
</main>

<?php get_footer(); ?>
